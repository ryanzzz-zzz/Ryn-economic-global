Salin isi folder res/ ke app/src/main/res/ (timpa jika nama sama).
AndroidManifest.xml (tag <application>):
  android:label="Ryn"
  android:icon="@mipmap/ic_launcher"
  android:roundIcon="@mipmap/ic_launcher_round"
Notifikasi: setSmallIcon(R.drawable.ic_ryn_notification)
Splash/Header/About: gunakan @drawable/ic_ryn_logo
Catatan: adaptive icon butuh API 26+. Untuk minSdk lebih rendah, tambahkan PNG launcher.
