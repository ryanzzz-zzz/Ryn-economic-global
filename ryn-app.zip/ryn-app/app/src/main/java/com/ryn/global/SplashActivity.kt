package com.ryn.global

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val content = findViewById<View>(R.id.splashContent)
        content.alpha = 0f
        content.scaleX = 0.9f
        content.scaleY = 0.9f
        content.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start()

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }, 1800)
    }
}
