package com.ryn.global

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<android.view.View>(R.id.btnAbout).setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }

        val container = findViewById<LinearLayout>(R.id.container)
        val sections = listOf(
            Triple("calendar", "Economic Calendar", "This week's high and medium impact events with forecast and previous values."),
            Triple("news", "Financial News", "Latest global business headlines."),
            Triple("macro", "Macro Data", "Inflation, GDP growth, and unemployment for major economies."),
            Triple("scenarios", "Market Scenarios", "Model-generated scenarios with probability estimates and reasoning.")
        )
        for ((key, title, body) in sections) {
            val card = layoutInflater.inflate(R.layout.item_card, container, false)
            card.findViewById<TextView>(R.id.cardTitle).text = title
            card.findViewById<TextView>(R.id.cardBody).text = body
            card.setOnClickListener {
                startActivity(
                    Intent(this, SectionActivity::class.java)
                        .putExtra("key", key)
                        .putExtra("title", title)
                )
            }
            container.addView(card)
        }
    }
}
