package com.ryn.global

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<android.view.View>(R.id.btnAbout).setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }

        val container = findViewById<LinearLayout>(R.id.container)
        val sections = listOf(
            Triple("calendar", "US Economic Calendar", "This week's US high and medium impact events with forecast and previous values."),
            Triple("news", "US Financial News", "Latest US economy, Fed, and market headlines."),
            Triple("macro", "US Macro Data", "Real yields, dollar index, Fed rate, inflation, and jobs."),
            Triple("scenarios", "XAUUSD Scenarios", "Scenario estimates with reasoning, based on US high-impact events.")
        )
        for ((key, title, body) in sections) {
            val card = layoutInflater.inflate(R.layout.item_card, container, false)
            card.findViewById<TextView>(R.id.cardTitle).text = title
            card.findViewById<TextView>(R.id.cardBody).text = body
            card.setOnClickListener {
                startActivity(
                    Intent(this, SectionActivity::class.java)
                        .putExtra("key", key)
                        .putExtra("title", title)
                )
            }
            container.addView(card)
        }
    }
}
