package com.ryn.global

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<android.view.View>(R.id.btnAbout).setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }

        val container = findViewById<LinearLayout>(R.id.container)
        val sections = listOf(
            "Economic Calendar" to "Upcoming high-impact economic events will appear here. Data feed not connected yet.",
            "Financial News" to "Global market headlines will appear here. Data feed not connected yet.",
            "Macro Data" to "Inflation, employment, rates, and growth indicators will appear here. Data feed not connected yet.",
            "Market Scenarios" to "Model-generated scenarios and probability estimates will appear here. Data feed not connected yet."
        )
        for ((title, body) in sections) {
            val card = layoutInflater.inflate(R.layout.item_card, container, false)
            card.findViewById<TextView>(R.id.cardTitle).text = title
            card.findViewById<TextView>(R.id.cardBody).text = body
            container.addView(card)
        }
    }
}
