package com.ryn.global

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SectionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_section)

        findViewById<TextView>(R.id.sectionTitle).text = intent.getStringExtra("title") ?: ""
        findViewById<TextView>(R.id.sectionDesc).text = intent.getStringExtra("body") ?: ""
        findViewById<android.view.View>(R.id.btnBack).setOnClickListener { finish() }
    }
}
