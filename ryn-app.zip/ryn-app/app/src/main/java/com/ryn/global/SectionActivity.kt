package com.ryn.global

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SectionActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var container: LinearLayout
    private var key = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_section)

        key = intent.getStringExtra("key") ?: ""
        findViewById<TextView>(R.id.sectionTitle).text = intent.getStringExtra("title") ?: ""
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        status = findViewById(R.id.sectionStatus)
        container = findViewById(R.id.sectionContainer)

        findViewById<TextView>(R.id.sectionDesc).text = when (key) {
            "calendar" -> "High and medium impact events for the current week, shown in your local time."
            "news" -> "Latest global business headlines. Tap a headline to read the full story."
            "macro" -> "Latest annual figures per country. Annual data is published with a delay."
            "scenarios" -> getString(R.string.about_disclaimer)
            else -> ""
        }
        status.setOnClickListener { load() }
        load()
    }

    private fun timeText(ms: Long): String =
        if (ms <= 0) "-" else SimpleDateFormat("EEE d MMM, HH:mm", Locale.getDefault()).format(Date(ms))

    private fun addCard(title: String, body: String, onClick: (() -> Unit)? = null): View {
        val card = layoutInflater.inflate(R.layout.item_card, container, false)
        card.findViewById<TextView>(R.id.cardTitle).text = title
        card.findViewById<TextView>(R.id.cardBody).text = body
        if (onClick != null) card.setOnClickListener { onClick() } else card.isClickable = false
        container.addView(card)
        return card
    }

    private fun load() {
        status.text = "Loading..."
        container.removeAllViews()
        Thread {
            try {
                when (key) {
                    "calendar" -> {
                        val ev = Repo.calendar().filter { it.impact == "High" || it.impact == "Medium" }
                            .sortedBy { it.time }
                        runOnUiThread {
                            if (isFinishing) return@runOnUiThread
                            status.text = if (ev.isEmpty()) "No events found." else "Source: Forex Factory calendar feed. Tap to refresh."
                            for (e in ev) {
                                val body = "${timeText(e.time)} - Impact: ${e.impact}\n" +
                                    "Forecast: ${e.forecast.ifBlank { "-" }}  Previous: ${e.previous.ifBlank { "-" }}" +
                                    (if (e.actual.isNotBlank()) "  Actual: ${e.actual}" else "")
                                addCard("${e.currency} - ${e.title}", body)
                            }
                        }
                    }
                    "news" -> {
                        val items = Repo.news()
                        runOnUiThread {
                            if (isFinishing) return@runOnUiThread
                            status.text = if (items.isEmpty()) "No headlines found." else "Source: BBC News. Tap to refresh."
                            for (n in items) {
                                addCard(n.title, "${n.source} - ${timeText(n.time)}") {
                                    if (n.link.isNotEmpty())
                                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(n.link)))
                                }
                            }
                        }
                    }
                    "macro" -> {
                        val data = Repo.macro()
                        runOnUiThread {
                            if (isFinishing) return@runOnUiThread
                            status.text = "Source: World Bank (annual data). Tap to refresh."
                            for ((name, lines) in data) {
                                addCard(name, if (lines.isEmpty()) "No data." else lines.joinToString("\n"))
                            }
                        }
                    }
                    "scenarios" -> {
                        val list = Repo.calendar().filter { it.impact == "High" }.sortedBy { it.time }
                            .mapNotNull { Repo.scenario(it) }
                        runOnUiThread {
                            if (isFinishing) return@runOnUiThread
                            status.text = if (list.isEmpty()) "No scenarios available for this week yet." else "Based on this week's high-impact events. Tap to refresh."
                            for (s in list) {
                                val cur = s.event.currency
                                val body = "${timeText(s.event.time)}\n" +
                                    "Bullish $cur ${s.bullish}%  -  Bearish $cur ${100 - s.bullish}%\n\n" + s.reasons
                                val card = addCard("$cur - ${s.event.title}", body)
                                val bar = card.findViewById<LinearLayout>(R.id.barRow)
                                bar.visibility = View.VISIBLE
                                val up = View(this).apply {
                                    setBackgroundColor(Color.parseColor("#22E1FF"))
                                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, s.bullish.toFloat())
                                }
                                val down = View(this).apply {
                                    setBackgroundColor(Color.parseColor("#FF5C7A"))
                                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, (100 - s.bullish).toFloat())
                                }
                                bar.addView(up)
                                bar.addView(down)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (!isFinishing) status.text = "Could not load data (${e.message}). Tap to retry."
                }
            }
        }.start()
    }
}
