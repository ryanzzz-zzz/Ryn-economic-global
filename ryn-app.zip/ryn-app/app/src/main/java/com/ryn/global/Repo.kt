package com.ryn.global

import android.util.Xml
import org.json.JSONArray
import org.xmlpull.v1.XmlPullParser
import java.io.IOException
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

data class CalEvent(
    val title: String, val currency: String, val time: Long, val impact: String,
    val forecast: String, val previous: String, val actual: String
)

data class NewsItem(val title: String, val link: String, val time: Long, val source: String)

data class Scenario(val event: CalEvent, val bullish: Int, val reasons: String)

object Repo {
    private const val CAL_URL = "https://cdn-nfs.faireconomy.media/ff_calendar_thisweek.json"
    private const val NEWS_URL = "https://feeds.bbci.co.uk/news/business/rss.xml"

    private var calCache: List<CalEvent>? = null
    private var calAt = 0L

    private fun http(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "Ryn/1.0 (Android)")
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun calendar(): List<CalEvent> {
        val now = System.currentTimeMillis()
        val cached = calCache
        if (cached != null && now - calAt < 600000) return cached
        val arr = JSONArray(http(CAL_URL))
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)
        val out = ArrayList<CalEvent>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val t = try { fmt.parse(o.optString("date"))?.time ?: 0L } catch (e: Exception) { 0L }
            out.add(
                CalEvent(
                    o.optString("title"), o.optString("country"), t, o.optString("impact"),
                    o.optString("forecast"), o.optString("previous"), o.optString("actual")
                )
            )
        }
        calCache = out
        calAt = now
        return out
    }

    fun news(): List<NewsItem> {
        val text = http(NEWS_URL)
        val p = Xml.newPullParser()
        p.setInput(StringReader(text))
        val fmt = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US)
        val out = ArrayList<NewsItem>()
        var inItem = false
        var tag = ""
        var title = ""; var link = ""; var date = ""
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> {
                    tag = p.name
                    if (tag == "item") { inItem = true; title = ""; link = ""; date = "" }
                }
                XmlPullParser.TEXT -> if (inItem) {
                    when (tag) {
                        "title" -> title += p.text
                        "link" -> link += p.text
                        "pubDate" -> date += p.text
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (p.name == "item") {
                        inItem = false
                        val t = try { fmt.parse(date.trim())?.time ?: 0L } catch (e: Exception) { 0L }
                        out.add(NewsItem(title.trim(), link.trim(), t, "BBC News"))
                    }
                    tag = ""
                }
            }
            ev = p.next()
        }
        return out.take(30)
    }

    /** Data makro tahunan dari World Bank: (judul indikator, baris per negara). */
    fun macro(): List<Pair<String, List<String>>> {
        val indicators = listOf(
            "Inflation (CPI, annual %)" to "FP.CPI.TOTL.ZG",
            "GDP growth (annual %)" to "NY.GDP.MKTP.KD.ZG",
            "Unemployment rate (% of labor force)" to "SL.UEM.TOTL.ZS"
        )
        val out = ArrayList<Pair<String, List<String>>>()
        for ((name, id) in indicators) {
            val url = "https://api.worldbank.org/v2/country/US;GB;JP;CN;ID/indicator/$id" +
                "?format=json&mrnev=1&per_page=20"
            val root = JSONArray(http(url))
            val data = root.optJSONArray(1)
            val lines = ArrayList<String>()
            if (data != null) {
                for (i in 0 until data.length()) {
                    val o = data.getJSONObject(i)
                    if (o.isNull("value")) continue
                    val country = o.getJSONObject("country").getString("value")
                    val v = o.getDouble("value")
                    lines.add(String.format(Locale.US, "%s: %.1f%% (%s)", country, v, o.getString("date")))
                }
            }
            out.add(name to lines)
        }
        return out
    }

    private fun parseNum(s: String): Pair<Double, Boolean>? {
        var t = s.trim()
        if (t.isEmpty()) return null
        val pct = t.contains('%')
        t = t.replace("%", "").replace(",", "").replace("<", "").replace(">", "").trim()
        var mult = 1.0
        if (t.endsWith("K", true)) { mult = 1e3; t = t.dropLast(1) }
        else if (t.endsWith("M", true)) { mult = 1e6; t = t.dropLast(1) }
        else if (t.endsWith("B", true)) { mult = 1e9; t = t.dropLast(1) }
        else if (t.endsWith("T", true)) { mult = 1e12; t = t.dropLast(1) }
        val v = t.trim().toDoubleOrNull() ?: return null
        return Pair(v * mult, pct)
    }

    /** +1: angka lebih tinggi cenderung mendukung mata uang; -1: menekan; 0: tidak dinilai. */
    private fun polarity(title: String): Int {
        val t = title.lowercase(Locale.US)
        if (t.contains("unemployment") || t.contains("jobless")) return -1
        val up = listOf(
            "non-farm", "nonfarm", "employment change", "payroll", "gdp", "retail sales", "cpi", "ppi",
            "pmi", "ism", "hourly earnings", "industrial production", "confidence", "sentiment",
            "trade balance", "interest rate", "inflation"
        )
        return if (up.any { t.contains(it) }) 1 else 0
    }

    private fun gap(a: Pair<Double, Boolean>, b: Pair<Double, Boolean>): Double {
        val base = if (a.second) (a.first - b.first) * 30.0
        else if (b.first != 0.0) (a.first - b.first) / abs(b.first) * 40.0
        else 0.0
        return base.coerceIn(-20.0, 20.0)
    }

    fun scenario(e: CalEvent): Scenario? {
        val pol = polarity(e.title)
        if (pol == 0) return null
        val f = parseNum(e.forecast)
        val p = parseNum(e.previous)
        val a = parseNum(e.actual)
        val cur = e.currency
        val shift: Double
        val why = StringBuilder()
        if (a != null && f != null) {
            shift = gap(a, f) * 1.5 * pol
            why.append("Actual ${e.actual} vs forecast ${e.forecast}: ")
            why.append(
                when {
                    shift > 1 -> "the result beat expectations in a way that supports $cur. "
                    shift < -1 -> "the result missed expectations in a way that weighs on $cur. "
                    else -> "the result is roughly in line with expectations. "
                }
            )
        } else if (f != null && p != null) {
            val g = gap(f, p)
            shift = g * pol
            val dir = when { g > 0.5 -> "higher"; g < -0.5 -> "lower"; else -> "about the same" }
            why.append("Forecast ${e.forecast} vs previous ${e.previous}: the market expects a $dir reading. ")
            why.append(
                if (pol > 0) "For this indicator, higher readings usually support $cur (stronger growth or tighter policy expectations). "
                else "For this indicator, higher readings usually weigh on $cur (weaker labor market). "
            )
        } else return null
        val bull = (50 + shift).roundToInt().coerceIn(30, 70)
        why.append(
            when {
                bull >= 55 -> "The scenario leans bullish on $cur. "
                bull <= 45 -> "The scenario leans bearish on $cur. "
                else -> "There is no clear edge; the scenario is close to neutral. "
            }
        )
        why.append("Consensus is usually already priced in, so the actual result versus forecast matters most.")
        return Scenario(e, bull, why.toString())
    }
}
