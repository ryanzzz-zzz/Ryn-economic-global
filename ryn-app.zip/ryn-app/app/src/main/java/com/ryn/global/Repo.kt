package com.ryn.global

import android.util.Xml
import org.json.JSONArray
import org.xmlpull.v1.XmlPullParser
import java.io.IOException
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

data class CalEvent(
    val title: String, val currency: String, val time: Long, val impact: String,
    val forecast: String, val previous: String, val actual: String
)

data class NewsItem(val title: String, val link: String, val time: Long, val source: String)

data class Scenario(val event: CalEvent, val usdBull: Int, val goldBull: Int, val reasons: String)

object Repo {
    private const val CAL_URL = "https://cdn-nfs.faireconomy.media/ff_calendar_thisweek.json"
    private const val WSJ_URL = "https://feeds.a.dj.com/rss/WSJcomUSBusiness.xml"
    private const val BBC_URL = "https://feeds.bbci.co.uk/news/business/rss.xml"

    private val usKeywords = Regex(
        "(^|[^A-Za-z])(US|U\\.S\\.)([^A-Za-z]|$)|Fed\\b|Powell|Trump|[Dd]ollar|Treasury|Wall Street|American|[Tt]ariff|[Gg]old|Nasdaq|S&P"
    )

    private var calCache: List<CalEvent>? = null
    private var calAt = 0L

    private fun http(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "Ryn/1.0 (Android)")
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun calendar(): List<CalEvent> {
        val now = System.currentTimeMillis()
        val cached = calCache
        if (cached != null && now - calAt < 600000) return cached
        val arr = JSONArray(http(CAL_URL))
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)
        val out = ArrayList<CalEvent>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val t = try { fmt.parse(o.optString("date"))?.time ?: 0L } catch (e: Exception) { 0L }
            out.add(
                CalEvent(
                    o.optString("title"), o.optString("country"), t, o.optString("impact"),
                    o.optString("forecast"), o.optString("previous"), o.optString("actual")
                )
            )
        }
        calCache = out
        calAt = now
        return out
    }

    private fun parseDate(s: String): Long {
        val a = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US)
        val b = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z", Locale.US)
        return try { a.parse(s.trim())?.time ?: 0L } catch (e: Exception) {
            try { b.parse(s.trim())?.time ?: 0L } catch (e2: Exception) { 0L }
        }
    }

    private fun parseFeed(url: String, source: String, onlyUs: Boolean): List<NewsItem> {
        val p = Xml.newPullParser()
        p.setInput(StringReader(http(url)))
        val out = ArrayList<NewsItem>()
        var inItem = false
        var tag = ""
        var title = ""; var link = ""; var date = ""
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> {
                    tag = p.name
                    if (tag == "item") { inItem = true; title = ""; link = ""; date = "" }
                }
                XmlPullParser.TEXT, XmlPullParser.CDSECT -> if (inItem) {
                    when (tag) {
                        "title" -> title += p.text
                        "link" -> link += p.text
                        "pubDate" -> date += p.text
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (p.name == "item") {
                        inItem = false
                        val t = title.trim()
                        if (t.isNotEmpty() && (!onlyUs || usKeywords.containsMatchIn(t))) {
                            out.add(NewsItem(t, link.trim(), parseDate(date), source))
                        }
                    }
                    tag = ""
                }
            }
            ev = p.next()
        }
        return out
    }

    fun news(): List<NewsItem> {
        val all = ArrayList<NewsItem>()
        var ok = 0
        try { all.addAll(parseFeed(WSJ_URL, "WSJ", false)); ok++ } catch (e: Exception) { }
        try { all.addAll(parseFeed(BBC_URL, "BBC News", true)); ok++ } catch (e: Exception) { }
        if (ok == 0) throw IOException("no news feed reachable")
        return all.sortedByDescending { it.time }.take(40)
    }

    private fun fred(id: String): List<Pair<String, Double>> {
        val c = Calendar.getInstance()
        c.add(Calendar.YEAR, -2)
        val start = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)
        val text = http("https://fred.stlouisfed.org/graph/fredgraph.csv?id=$id&cosd=$start")
        val out = ArrayList<Pair<String, Double>>()
        for (line in text.lineSequence().drop(1)) {
            val parts = line.trim().split(',')
            if (parts.size < 2) continue
            val v = parts[1].toDoubleOrNull() ?: continue
            out.add(parts[0] to v)
        }
        return out
    }

    private fun safeFred(id: String): List<Pair<String, Double>> =
        try { fred(id) } catch (e: Exception) { emptyList() }

    private fun level(label: String, s: List<Pair<String, Double>>, unit: String): String =
        if (s.isEmpty()) "$label: n/a"
        else String.format(Locale.US, "%s: %.2f%s (%s)", label, s.last().second, unit, s.last().first)

    /** Data makro AS dari FRED (CSV publik, tanpa API key). */
    fun macro(): List<Pair<String, List<String>>> {
        val real = safeFred("DFII10")
        val y10 = safeFred("DGS10")
        val usd = safeFred("DTWEXBGS")
        val ff = safeFred("DFF")
        val un = safeFred("UNRATE")
        val cpi = safeFred("CPIAUCSL")
        val pay = safeFred("PAYEMS")

        val drivers = listOf(
            level("10Y real yield", real, "%"),
            level("10Y Treasury yield", y10, "%"),
            level("Broad US dollar index", usd, ""),
            level("Fed funds effective rate", ff, "%")
        )
        val cpiLine = if (cpi.size >= 13) {
            val yoy = (cpi.last().second / cpi[cpi.size - 13].second - 1) * 100
            String.format(Locale.US, "CPI inflation (YoY): %.1f%% (%s)", yoy, cpi.last().first)
        } else "CPI inflation (YoY): n/a"
        val payLine = if (pay.size >= 2) {
            val d = pay.last().second - pay[pay.size - 2].second
            String.format(Locale.US, "Nonfarm payrolls (monthly change): %+.0fK (%s)", d, pay.last().first)
        } else "Nonfarm payrolls (monthly change): n/a"
        val economy = listOf(level("Unemployment rate", un, "%"), cpiLine, payLine)

        if (real.isEmpty() && y10.isEmpty() && un.isEmpty() && cpi.isEmpty()) throw IOException("FRED not reachable")
        return listOf(
            "Gold drivers (daily)" to drivers,
            "US economy (monthly)" to economy
        )
    }

    private fun parseNum(s: String): Pair<Double, Boolean>? {
        var t = s.trim()
        if (t.isEmpty()) return null
        val pct = t.contains('%')
        t = t.replace("%", "").replace(",", "").replace("<", "").replace(">", "").trim()
        var mult = 1.0
        if (t.endsWith("K", true)) { mult = 1e3; t = t.dropLast(1) }
        else if (t.endsWith("M", true)) { mult = 1e6; t = t.dropLast(1) }
        else if (t.endsWith("B", true)) { mult = 1e9; t = t.dropLast(1) }
        else if (t.endsWith("T", true)) { mult = 1e12; t = t.dropLast(1) }
        val v = t.trim().toDoubleOrNull() ?: return null
        return Pair(v * mult, pct)
    }

    /** +1: angka lebih tinggi cenderung mendukung USD; -1: menekan USD; 0: tidak dinilai. */
    private fun polarity(title: String): Int {
        val t = title.lowercase(Locale.US)
        if (t.contains("unemployment") || t.contains("jobless")) return -1
        val up = listOf(
            "non-farm", "nonfarm", "employment change", "payroll", "gdp", "retail sales", "cpi", "ppi",
            "pmi", "ism", "hourly earnings", "industrial production", "confidence", "sentiment",
            "trade balance", "interest rate", "inflation", "pce", "jolts", "durable goods"
        )
        return if (up.any { t.contains(it) }) 1 else 0
    }

    private fun gap(a: Pair<Double, Boolean>, b: Pair<Double, Boolean>): Double {
        val base = if (a.second) (a.first - b.first) * 30.0
        else if (b.first != 0.0) (a.first - b.first) / abs(b.first) * 40.0
        else 0.0
        return base.coerceIn(-20.0, 20.0)
    }

    fun scenario(e: CalEvent): Scenario? {
        val pol = polarity(e.title)
        if (pol == 0) return null
        val f = parseNum(e.forecast)
        val p = parseNum(e.previous)
        val a = parseNum(e.actual)
        val shift: Double
        val why = StringBuilder()
        if (a != null && f != null) {
            shift = gap(a, f) * 1.5 * pol
            why.append("Actual ${e.actual} vs forecast ${e.forecast}: ")
            why.append(
                when {
                    shift > 1 -> "the result beat expectations in a way that supports the US dollar. "
                    shift < -1 -> "the result missed expectations in a way that weighs on the US dollar. "
                    else -> "the result is roughly in line with expectations. "
                }
            )
        } else if (f != null && p != null) {
            val g = gap(f, p)
            shift = g * pol
            val dir = when { g > 0.5 -> "higher"; g < -0.5 -> "lower"; else -> "about the same" }
            why.append("Forecast ${e.forecast} vs previous ${e.previous}: the market expects a $dir reading. ")
            why.append(
                if (pol > 0) "For this indicator, higher readings usually support the US dollar (stronger growth or tighter Fed expectations). "
                else "For this indicator, higher readings usually weigh on the US dollar (weaker labor market). "
            )
        } else return null
        val usd = (50 + shift).roundToInt().coerceIn(30, 70)
        val gold = 100 - usd
        why.append(
            when {
                usd >= 55 -> "The scenario leans bullish on USD, which usually weighs on XAUUSD. "
                usd <= 45 -> "The scenario leans bearish on USD, which usually supports XAUUSD. "
                else -> "There is no clear edge; the scenario is close to neutral for both USD and XAUUSD. "
            }
        )
        why.append("Consensus is usually already priced in, so the actual result versus forecast matters most.")
        return Scenario(e, usd, gold, why.toString())
    }
}
